/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package correo;

import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 *
 * @author Angel
 */
public class Correo {
    
    Properties props = new Properties();
    Session session;
    MimeMessage message;
    
    public Correo(){
        // Nombre del host de correo, es smtp.gmail.com
        this.props.setProperty("mail.smtp.host", "smtp.gmail.com");

        // TLS si está disponible
        this.props.setProperty("mail.smtp.starttls.enable", "true");

        // Puerto de gmail para envio de correos
        this.props.setProperty("mail.smtp.port","587");

        // Nombre del usuario
        this.props.setProperty("mail.smtp.user", "ejemplo@gmail.com");

        // Si requiere o no usuario y password para conectarse.
        this.props.setProperty("mail.smtp.auth", "true");
        
        this.session = Session.getDefaultInstance(this.props);
        //session.setDebug(true);     Para obtener mas info por la pantalla
        this.message=new MimeMessage(session);
    }
    
    
    public void construirMsg(String remitente,String destinatario,String asunto,String mensaje){
        try{
            // Quien envia el correo
            this.message.setFrom(new InternetAddress(remitente));

            // A quien va dirigido
            this.message.addRecipient(Message.RecipientType.TO, new InternetAddress(destinatario));
            
            this.message.setSubject(asunto);//asunto
            this.message.setText(mensaje);//mensaje
        }catch(Exception ex){
            System.err.println(ex.getMessage());
        }
    }
    
    
    
    public void enviarCorreo(String usuario,String contrasenia){
        try {
            Transport t = session.getTransport("smtp");
            t.connect(usuario,contrasenia);
            t.sendMessage(message,message.getAllRecipients());
            t.close();
        } catch (MessagingException ex) {
            ex.getMessage();
        }
       
    }
        
}
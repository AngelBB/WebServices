/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sv_calculadora;

import calculadora.FuncionesCalculadora_Service;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.ws.WebServiceRef;

/**
 *
 * @author Angel
 */
@WebServlet(name = "Servlet_Calculadora", urlPatterns = {"/Servlet_Calculadora"})
public class Servlet_Calculadora extends HttpServlet {
    @WebServiceRef(wsdlLocation = "WEB-INF/wsdl/localhost_8080/ServidorCalculadora/FuncionesCalculadora.wsdl")
    private FuncionesCalculadora_Service service;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        // PrintWriter out = response.getWriter()
       
        
        
        
        
    }
    private double dividir(int num1, int num2) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        calculadora.FuncionesCalculadora port = service.getFuncionesCalculadoraPort();
        return port.dividir(num1, num2);
    }

    private int multiplicar(int num1, int num2) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        calculadora.FuncionesCalculadora port = service.getFuncionesCalculadoraPort();
        return port.multiplicar(num1, num2);
    }

    private int restar(int num1, int num2) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        calculadora.FuncionesCalculadora port = service.getFuncionesCalculadoraPort();
        return port.restar(num1, num2);
    }

    private int sumar(int num1, int num2) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        calculadora.FuncionesCalculadora port = service.getFuncionesCalculadoraPort();
        return port.sumar(num1, num2);
    }
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        PrintWriter out = response.getWriter();
        
        try{
            //Procesmoa la informacion que nos llega
            int valor1=new Integer(request.getParameter("valor1"));
            int valor2=new Integer(request.getParameter("valor2"));
            String operacion=request.getParameter("operacion");
            int resultado=0;

                //Creamos un switch con los posibles casos
                switch(operacion){
                    case "sumar": resultado=sumar(valor1,valor2);
                                    out.print(resultado);
                    break;

                    case "restar": resultado=restar(valor1,valor2);
                                    out.print(resultado);
                    break;

                    case "multiplicar": resultado=multiplicar(valor1,valor2);
                                    out.print(resultado);
                    break;

                    case "dividir": Double res=dividir(valor1,valor2);
                                    out.print(res);
                    break;
                }
        }catch(Exception ex){
            ex.getMessage();
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}

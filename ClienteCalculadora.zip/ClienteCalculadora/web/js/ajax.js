function validarDatos(){
	var usuario=$('#user').val();
	var pw=$('#pass').val();
	
	$.ajax({
	  type: "POST",
	  url: "Servlet_login",
	  data: { user:usuario , pass:pw }
	});
	return false;
}

function msgError(mensaje){
    if(mensaje=="Error"){
            $('#bd-danger').css("display", "block");
            //Otras formas
            /*$('#id').hide();
            $('#id').show();*/
    }
}

function hacerCalculos(){
    var v1=$('#valor1').val();
    var v2=$('#valor2').val();
    var op=$('#operacion option:selected').text();//opcion seleccionada
    
    $.ajax({
            type: "POST",
            url: "Servlet_Calculadora",
            data: {valor1:v1, valor2:v2, operacion:op},
            success: function(respuesta){//Recibimos el resultado
                $('#resultado').val(respuesta);
            }
        });
    return false;
}


function ordenarNumeros(){
    var n1=$("#numero1").val();
    var n2=$("#numero2").val();
    var n3=$("#numero3").val();
    $.ajax({
            type: "POST",
            url: "Sv_ordenar_vector",
            data: {num1:n1, num2:n2, num3:n3},
            success: function(respuesta){//Recibimos el resultado
                $('#numsOrdenados').val(respuesta);
            }
        });
    return false;
}


function mandarCorreo(){
    var correo_destino=$("#correo_destino").val();
    var vector_ordenado=$('#numsOrdenados').val();
    $.ajax({
            type: "POST",
            url: "Sv_correo",
            data: {destinatario:correo_destino,valores:vector_ordenado},
            success: function(respuesta){//Recibimos el resultado
                alert(respuesta);
            }
        });
}


$(document).ready(function(){
    $('#acceder').click(validarDatos);
    $('#calcular').click(hacerCalculos);
    $('#ordenar').click(ordenarNumeros);
    $('#enviarCorreo').click(mandarCorreo);
});
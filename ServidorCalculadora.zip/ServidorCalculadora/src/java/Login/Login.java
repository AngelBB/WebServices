/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import com.mysql.jdbc.*;

/**
 *
 * @author Angel
 */
@WebService(serviceName = "Login")
public class Login {

    @WebMethod(operationName = "validarDatos")
    public boolean validarDatos(@WebParam(name = "user") String usuario,@WebParam(name = "pass") String pass) {
        boolean acceder=false;
        try{
            Class.forName("com.mysql.jdbc.Driver");//Para asegurarnos cargar el driver MYSQL
            String conexionBD="jdbc:mysql://localhost:3306/spotify";
            Connection conexion=null;
            String con;
            conexion=DriverManager.getConnection(conexionBD,"2dam","2dam");//conexion a la base de datos
            Statement s = conexion.createStatement();
            con= "SELECT * FROM users WHERE LOGIN='"+usuario+"' AND PASS='"+pass+"'";
            ResultSet rs= s.executeQuery(con);
            if(rs.next()){
                acceder=true;
            }      
            
        }catch(Exception e){
            System.out.println("No se ha completado la peticion...");
        }
        return acceder;
    }
}
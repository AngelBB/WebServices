/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ordenar_vector;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Angel
 */
@WebService(serviceName = "Ordenar_vector")
public class Ordenar_vector {

    /**
     * This is a sample web service operation
     * @param n1
     * @param n2
     * @param n3
     */
    
    @WebMethod(operationName = "ordenarVector")
    public String ordenarVector(@WebParam(name = "numero1") int n1,@WebParam(name = "numero2") int n2,@WebParam(name = "numero3") int n3) {
        String numeros;
        String enviar="";
        try{
            //Invocamos al programa externo
            Process aplicacion = Runtime.getRuntime().exec("C:/ordenarvector.exe "+n1+" "+n2+" "+n3);  
            
            /* Se obtiene el stream de salida del programa */
            InputStream is = aplicacion.getInputStream();
            
            /* Se prepara un BufferedReader para poder leer la salida más comodamente. */
            BufferedReader br = new BufferedReader (new InputStreamReader (is)); 

            enviar=enviar.concat(br.readLine()+"<");
            enviar=enviar.concat(br.readLine()+"<");
            enviar=enviar.concat(br.readLine());
            
        }catch(Exception e){}
        return enviar;
    }
}
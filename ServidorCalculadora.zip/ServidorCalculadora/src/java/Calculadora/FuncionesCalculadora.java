/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Calculadora;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Angel
 */
@WebService(serviceName = "FuncionesCalculadora")
public class FuncionesCalculadora {

    /**
     * This is a sample web service operation
     * @param num1
     * @param num2
     */
    @WebMethod(operationName = "sumar")
    public int sumar(@WebParam(name = "num1") int num1,@WebParam(name = "num2") int num2) {
        return num1+num2;
    }
    
    @WebMethod(operationName = "restar")
    public int restar(@WebParam(name = "num1") int num1,@WebParam(name = "num2") int num2) {
        return num1-num2;
    }
    
    @WebMethod(operationName = "multiplicar")
    public int multiplicar(@WebParam(name = "num1") int num1,@WebParam(name = "num2") int num2) {
        return num1*num2;
    }
    
    @WebMethod(operationName = "dividir")
    public double dividir(@WebParam(name = "num1") int num1,@WebParam(name = "num2") int num2) {
        return num1/num2;
    }
    
    
}

// ordenarvector.cpp: define el punto de entrada de la aplicaci�n de consola.

#include "stdafx.h"
#include <iostream>
#include <stdlib.h>
#include <sstream>
#include <string>

using namespace std;

int valores[3];
char ordenacion;
//Comenzamos el metodo de la burbuja y declaramos las variables que utilizaremos para dicho metodo
static int TAM = sizeof(valores) / sizeof(valores[0]);//tama�o del array
int i, j;
int temp;


int main(int argc, char *argv[]){//Le vamos a pasar 3 argumentos

	valores[0] = strtol(argv[1], NULL, 10);//la posicion 0 en argv no la ponemos ya que corresponde al nombre del programa
	valores[1] = strtol(argv[2], NULL, 10);
	valores[2] = strtol(argv[3], NULL, 10);
	
	//Si hemos seleccionado el proceso de menor a mayor comenzara el siguiente paso

	//Comienza el metodo de la burbuja
	for (i = 0; i<TAM; i++){
		for (j = i + 1; j<TAM; j++){
			if (valores[i] > valores[j]){
				temp = valores[i];
				valores[i] = valores[j];
				valores[j] = temp;
			}
		}
	}

	
	//Termina el metodo de la burbuja
	//Mostramos los valores
	for (i = 0; i < TAM; i++){
		cout << valores[i] << endl;
	}
}